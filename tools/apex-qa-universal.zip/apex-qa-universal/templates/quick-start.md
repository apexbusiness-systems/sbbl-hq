# APEX-QA Quick-Start Template (Universal Edition)

## How to Invoke (Any LLM Platform)

Paste the contents of `prompt.md` as the system prompt.
Then submit this structure as the user message:

---

**Scope (original ticket/request):**
[Paste the original feature request or ticket description]

**Submission (code, output, or feature description):**
[Paste the code, AI output, or feature description to audit]

**Declared Dependencies (optional):**
[List any libraries, APIs, or modules the submission claims to use]

---

## Expected Output

### VERIFICATION MATRIX — [your submission title]

| Check                     | Result | Evidence                        |
|---------------------------|--------|---------------------------------|
| Scope Alignment           | ✅/❌  | [finding]                       |
| Hallucination Scan        | ✅/❌  | [finding]                       |
| Ghost Feature Detection   | ✅/❌  | [finding]                       |
| TODO / Stub Audit         | ✅/❌  | [finding]                       |
| Test Coverage             | ✅/❌  | [finding]                       |

**VERDICT: [VERIFIED] | [REJECTED]**
> Remediation: [exact fix — on REJECT only]

---

## Platform Installation Notes

| Platform | System Prompt Location |
|----------|----------------------|
| OpenAI API | `messages[0].role = "system"` |
| Anthropic API | `system` parameter |
| Gemini API | `systemInstruction` field |
| Ollama | `system` field in Modelfile |
| LM Studio | System prompt field in chat UI |
| Any platform | Paste prompt.md before user message |

---

## Common Rejection Reasons & Fixes

| Rejection Reason | Fix |
|-----------------|-----|
| TODO detected | Complete the implementation — no deferred logic |
| Ghost feature | Remove code not in the original ticket |
| Phantom API | Verify the import exists and is in scope |
| No tests | Write tests for all changed functions before resubmission |
| Missing scope | Always include the original ticket/request as context |
